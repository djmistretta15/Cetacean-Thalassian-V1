# /validation — CetaSignal Scientific Validation Pipeline

This is the statistical validation layer for the CetaSignal cadence classifier.
It answers the question the GPT-4 review correctly identified as critical:

> **Does the cadence classifier perform better than chance on unseen data?**

---

## What This Is

A standalone Python validation framework that:

1. Loads labeled acoustic datasets (CSV/JSON)
2. Runs stratified k-fold cross-validation
3. Evaluates the cadence engine against three baselines
4. Computes accuracy, precision, recall, F1, confusion matrix, Cohen's kappa
5. Runs binomial significance test vs random baseline
6. Outputs publication-ready metrics reports and confusion matrix figures

**This module does not replace the frontend platform.** It is the scientific validation layer that converts the hypothesis engine into an experimentally falsifiable system.

---

## Module Files

| File | Purpose |
|------|---------|
| `dataset_loader.py` | Load CSV/JSON datasets, train/test split, k-fold |
| `cadence_engine.py` | Python port of the rule-based classifier |
| `baseline_models.py` | Random, majority class, frequency prior baselines |
| `feature_extractor.py` | Extract features from raw WAV files (optional) |
| `metrics.py` | Accuracy, F1, confusion matrix, kappa, significance |
| `evaluator.py` | Runs all models, compares results |
| `run_experiment.py` | CLI entry point — runs everything end-to-end |
| `requirements.txt` | Python dependencies |

---

## Quick Start

```bash
cd validation
pip install -r requirements.txt

# Test the pipeline on synthetic data first:
python run_experiment.py --synthetic --n 500 --kfold 5

# Run on real NOAA data:
python run_experiment.py --data your_dataset.csv --kfold 5
```

---

## Dataset Format

Your CSV or JSON must contain these columns:

| Field | Type | Description |
|-------|------|-------------|
| `peakFrequency_hz` | float | Dominant call frequency in Hz |
| `duration_s` | float | Call duration in seconds |
| `freqContour` | str | `rising` \| `descending` \| `flat` \| `complex` |
| `interPulseInterval_ms` | float | Mean IPI in milliseconds (NaN if tonal) |
| `urgencyIndex` | float | Composite urgency 0–1 |
| `repetitionHz` | float | Repetition rate in Hz |
| `groundTruthBehavior` | str | `CONTACT` \| `DIVE` \| `FORAGE` \| `NAVIGATE` \| `BROADCAST` |

You can derive these from NOAA/DCLDE annotation files using `feature_extractor.py` if you have raw WAV files.

---

## Getting Real Data

The NOAA NEFSC DCLDE 2013 dataset has annotations compatible with this format:
- URL: https://www.fisheries.noaa.gov/resource/data/noaa-nefsc-north-atlantic-right-whale-acoustic-data-and-annotations
- Format: Raven 1.5 annotation files (.txt) + corresponding WAV files
- Use `feature_extractor.py` to extract acoustic features from WAVs

The DCLDE 2022 Oahu dataset:
- DOI: https://doi.org/10.25921/e12p-gj65
- Available via NOAA NCEI
- Multi-species, 47 days, synchronized visual ground truth

---

## Output Files

After running `run_experiment.py`:

```
results/
├── dataset_summary.json          # Class distribution, feature stats
├── metrics_cadenceengine.json    # Full metrics for cadence engine
├── metrics_randomclassifier.json # Random baseline metrics
├── metrics_majorityclassifier.json
├── confusion_matrix_cadenceengine.png  # Publication-ready figure
├── summary_cadenceengine.txt     # Human-readable summary
├── comparison.json               # Side-by-side model comparison
└── comparison_summary.txt        # Interpretation + next steps
```

---

## Interpreting Results

| Accuracy range | Interpretation |
|---------------|----------------|
| < random (20%) | Rules inversely correlated — review thresholds |
| 20–40% | Marginally better than chance — significant? |
| 40–65% | Rules carry information — review confusion matrix |
| 65–80% | Strong rule-based performance — publishable |
| > 80% | Very strong — validate on independent dataset |

**Cohen's Kappa** is more important than raw accuracy for imbalanced classes:
- κ < 0.2: Poor agreement
- κ 0.2–0.4: Fair
- κ 0.4–0.6: Moderate — publishable for exploratory work
- κ > 0.6: Substantial — strong scientific claim

---

## Important Warning About Synthetic Data

The synthetic dataset generator (`--synthetic` flag) produces data from the same
distributional templates that inform the rule thresholds. Running the classifier
on synthetic data will produce artificially high accuracy — this tests pipeline
correctness, not scientific validity.

**Do not report synthetic results as scientific findings.**

Use real NOAA/DCLDE labeled datasets for any claims about model performance.

---

## After Validation

If the cadence engine achieves significant performance vs baselines on real data:

1. Document in `RESEARCH_NOTE.md` with: hypothesis, dataset, method, results, sample size, limitations
2. Generate confusion matrix figure with `metrics.py`
3. Open GitHub issue: "Validation v1.0 — [dataset name] — [accuracy]% accuracy"
4. This constitutes the empirical basis for contacting WHOI / Project CETI / NOAA

---

## Adding to the Frontend

The cadence engine in `cadence_engine.py` is the Python equivalent of `runCadenceModel()` in the frontend. Keep them in sync. Any rule changes made during validation should be reflected in both implementations.
