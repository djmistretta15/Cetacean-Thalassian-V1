"""
dataset_loader.py
─────────────────
Loads labeled cetacean acoustic metadata for validation experiments.

Supports:
  - CSV / JSON input
  - Train/test split
  - Stratified k-fold cross-validation
  - Synthetic dataset generation (for pipeline testing without real data)

Required fields in dataset:
  peakFrequency_hz      : float  - dominant frequency (Hz)
  duration_s            : float  - call duration (seconds)
  freqContour           : str    - rising | descending | flat | complex
  interPulseInterval_ms : float  - IPI in milliseconds (NaN if tonal)
  urgencyIndex          : float  - composite urgency 0–1
  repetitionHz          : float  - repetition rate (Hz)
  groundTruthBehavior   : str    - CONTACT | DIVE | FORAGE | NAVIGATE | BROADCAST

Usage:
  python dataset_loader.py --data dataset.csv --mode split --test_size 0.2
  python dataset_loader.py --data dataset.csv --mode kfold --folds 5
  python dataset_loader.py --mode synthetic --n 200
"""

import argparse
import json
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold

# ── Constants ────────────────────────────────────────────────────

RANDOM_SEED = 42

REQUIRED_FIELDS = [
    'peakFrequency_hz',
    'duration_s',
    'freqContour',
    'interPulseInterval_ms',
    'urgencyIndex',
    'repetitionHz',
    'groundTruthBehavior',
]

BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']

FREQ_CONTOUR_VALUES = ['rising', 'descending', 'flat', 'complex']

# ── Loader ───────────────────────────────────────────────────────

class CetaceanDatasetLoader:
    """
    Loads and validates cetacean acoustic metadata datasets.
    Provides train/test splits and k-fold cross-validation iterators.
    """

    def __init__(self, filepath: str = None, df: pd.DataFrame = None):
        """
        Args:
            filepath : path to CSV or JSON file
            df       : pre-loaded DataFrame (used by synthetic generator)
        """
        if df is not None:
            self.df = df
        elif filepath is not None:
            self.df = self._load(filepath)
        else:
            raise ValueError("Provide either filepath or df.")

        self._validate()
        self._coerce_types()
        print(f"[DatasetLoader] Loaded {len(self.df)} specimens across "
              f"{self.df['groundTruthBehavior'].nunique()} behavioral classes.")
        print(f"[DatasetLoader] Class distribution:\n"
              f"{self.df['groundTruthBehavior'].value_counts().to_string()}\n")

    def _load(self, filepath: str) -> pd.DataFrame:
        ext = os.path.splitext(filepath)[1].lower()
        if ext == '.csv':
            return pd.read_csv(filepath)
        elif ext == '.json':
            with open(filepath) as f:
                data = json.load(f)
            # Accept either a list of records or {"specimens": [...]}
            if isinstance(data, list):
                return pd.DataFrame(data)
            elif 'specimens' in data:
                return pd.DataFrame(data['specimens'])
            else:
                return pd.DataFrame(data)
        else:
            raise ValueError(f"Unsupported file type: {ext}. Use .csv or .json")

    def _validate(self):
        missing = [f for f in REQUIRED_FIELDS if f not in self.df.columns]
        if missing:
            raise ValueError(f"Dataset missing required fields: {missing}")

        invalid_classes = set(self.df['groundTruthBehavior'].unique()) - set(BEHAVIORAL_CLASSES)
        if invalid_classes:
            raise ValueError(f"Unknown behavioral classes in dataset: {invalid_classes}. "
                             f"Valid: {BEHAVIORAL_CLASSES}")

        invalid_contours = set(self.df['freqContour'].unique()) - set(FREQ_CONTOUR_VALUES)
        if invalid_contours:
            raise ValueError(f"Unknown freqContour values: {invalid_contours}. "
                             f"Valid: {FREQ_CONTOUR_VALUES}")

    def _coerce_types(self):
        self.df['peakFrequency_hz']      = pd.to_numeric(self.df['peakFrequency_hz'],      errors='coerce')
        self.df['duration_s']            = pd.to_numeric(self.df['duration_s'],            errors='coerce')
        self.df['interPulseInterval_ms'] = pd.to_numeric(self.df['interPulseInterval_ms'], errors='coerce')
        self.df['urgencyIndex']          = pd.to_numeric(self.df['urgencyIndex'],          errors='coerce')
        self.df['repetitionHz']          = pd.to_numeric(self.df['repetitionHz'],          errors='coerce')
        self.df.fillna({'interPulseInterval_ms': np.nan, 'repetitionHz': 0.0}, inplace=True)

    def get_features_and_labels(self):
        """Returns (features_df, labels_series)."""
        X = self.df[REQUIRED_FIELDS[:-1]].copy()
        y = self.df['groundTruthBehavior'].copy()
        return X, y

    def train_test_split(self, test_size: float = 0.2):
        """
        Stratified train/test split.
        Returns (X_train, X_test, y_train, y_test) as DataFrames/Series.
        """
        X, y = self.get_features_and_labels()
        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=test_size,
            stratify=y,
            random_state=RANDOM_SEED
        )
        print(f"[DatasetLoader] Split: {len(X_train)} train / {len(X_test)} test")
        return X_train, X_test, y_train, y_test

    def kfold_splits(self, n_splits: int = 5):
        """
        Stratified k-fold cross-validation iterator.
        Yields (fold_num, X_train, X_test, y_train, y_test) tuples.
        """
        X, y = self.get_features_and_labels()
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=RANDOM_SEED)
        for fold, (train_idx, test_idx) in enumerate(skf.split(X, y), start=1):
            yield (
                fold,
                X.iloc[train_idx], X.iloc[test_idx],
                y.iloc[train_idx], y.iloc[test_idx]
            )

    def summary(self) -> dict:
        """Returns a summary dict suitable for JSON serialization."""
        X, y = self.get_features_and_labels()
        return {
            'total_specimens': len(self.df),
            'class_distribution': y.value_counts().to_dict(),
            'feature_stats': X.describe().to_dict(),
            'classes': BEHAVIORAL_CLASSES,
            'class_balance': (y.value_counts() / len(y)).round(3).to_dict(),
        }


# ── Synthetic Dataset Generator ──────────────────────────────────

def generate_synthetic_dataset(n: int = 200, noise_level: float = 0.15) -> pd.DataFrame:
    """
    Generates a synthetic labeled dataset based on known acoustic ecology.
    Used for pipeline testing and baseline performance estimation.

    NOTE: Synthetic data is generated from the same rules as the classifier.
    Do NOT use synthetic data for real validation — use real NOAA/DCLDE data.
    This is for pipeline testing only.

    Args:
        n           : total number of specimens to generate
        noise_level : fraction of specimens with perturbed/ambiguous features
    """
    np.random.seed(RANDOM_SEED)
    records = []
    per_class = n // len(BEHAVIORAL_CLASSES)

    class_templates = {
        'CONTACT': {
            'peakFrequency_hz':      lambda: np.random.uniform(80, 400),
            'duration_s':            lambda: np.random.uniform(0.5, 3.0),
            'freqContour':           lambda: np.random.choice(['rising', 'rising', 'flat']),
            'interPulseInterval_ms': lambda: np.nan,
            'urgencyIndex':          lambda: np.random.uniform(0.1, 0.4),
            'repetitionHz':          lambda: np.random.uniform(0.05, 0.15),
        },
        'DIVE': {
            'peakFrequency_hz':      lambda: np.random.uniform(80, 350),
            'duration_s':            lambda: np.random.uniform(0.3, 1.8),
            'freqContour':           lambda: 'descending',
            'interPulseInterval_ms': lambda: np.random.uniform(600, 1800),
            'urgencyIndex':          lambda: np.random.uniform(0.2, 0.45),
            'repetitionHz':          lambda: np.random.uniform(0.0, 0.1),
        },
        'FORAGE': {
            'peakFrequency_hz':      lambda: np.random.uniform(1500, 6000),
            'duration_s':            lambda: np.random.uniform(0.5, 4.0),
            'freqContour':           lambda: np.random.choice(['flat', 'complex']),
            'interPulseInterval_ms': lambda: np.random.uniform(8, 45),
            'urgencyIndex':          lambda: np.random.uniform(0.55, 0.9),
            'repetitionHz':          lambda: np.random.uniform(3.0, 8.0),
        },
        'NAVIGATE': {
            'peakFrequency_hz':      lambda: np.random.uniform(15, 30),
            'duration_s':            lambda: np.random.uniform(2.5, 20.0),
            'freqContour':           lambda: 'flat',
            'interPulseInterval_ms': lambda: np.random.uniform(5000, 30000),
            'urgencyIndex':          lambda: np.random.uniform(0.02, 0.15),
            'repetitionHz':          lambda: np.random.uniform(0.02, 0.06),
        },
        'BROADCAST': {
            'peakFrequency_hz':      lambda: np.random.uniform(200, 1000),
            'duration_s':            lambda: np.random.uniform(5.0, 20.0),
            'freqContour':           lambda: 'complex',
            'interPulseInterval_ms': lambda: np.random.uniform(200, 600),
            'urgencyIndex':          lambda: np.random.uniform(0.05, 0.2),
            'repetitionHz':          lambda: np.random.uniform(0.08, 0.2),
        },
    }

    for cls, template in class_templates.items():
        for _ in range(per_class):
            record = {k: v() for k, v in template.items()}
            record['groundTruthBehavior'] = cls

            # Apply noise to simulate ambiguous/overlapping signals
            if np.random.random() < noise_level:
                record['freqContour'] = np.random.choice(FREQ_CONTOUR_VALUES)
                record['urgencyIndex'] = np.random.uniform(0, 1)

            records.append(record)

    df = pd.DataFrame(records)
    df = df.sample(frac=1, random_state=RANDOM_SEED).reset_index(drop=True)
    return df


# ── CLI ──────────────────────────────────────────────────────────

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CetaSignal Dataset Loader')
    parser.add_argument('--data',      type=str,   help='Path to CSV or JSON dataset')
    parser.add_argument('--mode',      type=str,   default='split',
                        choices=['split', 'kfold', 'synthetic', 'summary'])
    parser.add_argument('--test_size', type=float, default=0.2)
    parser.add_argument('--folds',     type=int,   default=5)
    parser.add_argument('--n',         type=int,   default=200,
                        help='Specimens for synthetic mode')
    parser.add_argument('--out',       type=str,   default='dataset_synthetic.csv')
    args = parser.parse_args()

    if args.mode == 'synthetic':
        df = generate_synthetic_dataset(n=args.n)
        df.to_csv(args.out, index=False)
        print(f"[DatasetLoader] Synthetic dataset ({args.n} specimens) saved → {args.out}")
        print(df['groundTruthBehavior'].value_counts().to_string())

    else:
        if not args.data:
            parser.error("--data required for modes: split, kfold, summary")

        loader = CetaceanDatasetLoader(filepath=args.data)

        if args.mode == 'summary':
            summary = loader.summary()
            print(json.dumps(summary, indent=2))

        elif args.mode == 'split':
            X_train, X_test, y_train, y_test = loader.train_test_split(args.test_size)
            print(f"Train samples: {len(X_train)}")
            print(f"Test  samples: {len(X_test)}")

        elif args.mode == 'kfold':
            for fold, X_tr, X_te, y_tr, y_te in loader.kfold_splits(args.folds):
                print(f"Fold {fold}: {len(X_tr)} train / {len(X_te)} test")
