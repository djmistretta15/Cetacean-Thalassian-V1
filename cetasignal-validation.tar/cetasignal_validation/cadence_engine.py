"""
cadence_engine.py
─────────────────
Python implementation of the CetaSignal cadence-to-behavior classifier.

Direct port of runCadenceModel() from the JavaScript frontend.
Both implementations must stay in sync — this is the validation layer.

Accepts either:
  - A dict of acoustic features
  - A pandas Series (one row from dataset)
  - A pandas DataFrame (batch prediction)

Output schema per specimen:
  {
    predicted_class : str,
    confidence      : float,
    probabilities   : dict,
    rule_trace      : list[dict],
    model_version   : str
  }

Usage:
  from cadence_engine import CadenceEngine
  engine = CadenceEngine()
  result = engine.predict({'peakFrequency_hz': 170, 'freqContour': 'rising', ...})
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field, asdict
from typing import Optional

# ── Constants ────────────────────────────────────────────────────

MODEL_VERSION = 'CadenceClassifier-v1.0-python (rule-based)'

BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']

# Base score ensures no class is completely shut out before rules apply
BASE_SCORE = 0.05


# ── Data structures ───────────────────────────────────────────────

@dataclass
class RuleTrace:
    rule: str
    contribution: str
    rationale: str
    feature_value: str


@dataclass
class PredictionResult:
    predicted_class: str
    confidence: float
    probabilities: dict
    rule_trace: list
    model_version: str = MODEL_VERSION

    def to_dict(self):
        return asdict(self)


# ── Engine ───────────────────────────────────────────────────────

class CadenceEngine:
    """
    Rule-based acoustic cadence → behavioral class classifier.

    Designed for transparency: every inference step is recorded in rule_trace.
    This is intentional — transparent classifiers are more publishable than
    black-box models for scientific validation purposes.
    """

    def predict(self, features) -> PredictionResult:
        """
        Predict behavioral class from acoustic features.

        Args:
            features : dict, pd.Series, or single-row pd.DataFrame

        Returns:
            PredictionResult
        """
        if isinstance(features, pd.DataFrame):
            if len(features) == 1:
                features = features.iloc[0]
            else:
                raise ValueError("Use predict_batch() for multiple rows.")
        if isinstance(features, pd.Series):
            features = features.to_dict()

        return self._run(features)

    def predict_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Batch predict across a DataFrame.
        Returns DataFrame with prediction columns appended.
        """
        results = []
        for _, row in df.iterrows():
            r = self._run(row.to_dict())
            results.append({
                'predicted_class': r.predicted_class,
                'confidence':      r.confidence,
                'rule_count':      len(r.rule_trace),
                **{f'prob_{cls}': r.probabilities.get(cls, 0) for cls in BEHAVIORAL_CLASSES}
            })
        result_df = pd.DataFrame(results, index=df.index)
        return pd.concat([df, result_df], axis=1)

    def _run(self, f: dict) -> PredictionResult:
        pf  = float(f.get('peakFrequency_hz', 200) or 200)
        fc  = str(f.get('freqContour', 'flat') or 'flat').lower().strip()
        dur = float(f.get('duration_s', 1.0) or 1.0)
        urg = float(f.get('urgencyIndex', 0.3) or 0.3)
        rep = float(f.get('repetitionHz', 0.0) or 0.0)

        raw_ipi = f.get('interPulseInterval_ms')
        ipi = None if (raw_ipi is None or (isinstance(raw_ipi, float) and np.isnan(raw_ipi))) \
              else float(raw_ipi)

        scores = {cls: BASE_SCORE for cls in BEHAVIORAL_CLASSES}
        trace  = []

        # ── Peak Frequency ────────────────────────────────────
        if pf < 50:
            scores['NAVIGATE'] += 0.35; scores['CONTACT'] += 0.25
            trace.append(RuleTrace('Peak frequency < 50 Hz', 'NAVIGATE +0.35 · CONTACT +0.25',
                'Infrasonic range. SOFAR channel exploitation. Long-range navigation or basin-scale contact.',
                f'{pf:.1f} Hz'))
        elif pf < 300:
            scores['CONTACT'] += 0.22; scores['DIVE'] += 0.18
            trace.append(RuleTrace('Peak frequency 50–300 Hz', 'CONTACT +0.22 · DIVE +0.18',
                'Low-mid baleen range. Contact calls and dive coordination signals cluster here.',
                f'{pf:.1f} Hz'))
        elif pf < 1200:
            scores['BROADCAST'] += 0.28; scores['CONTACT'] += 0.18
            trace.append(RuleTrace('Peak frequency 300–1200 Hz', 'BROADCAST +0.28 · CONTACT +0.18',
                'Mid-range. Humpback song and delphinid contact whistles.',
                f'{pf:.1f} Hz'))
        else:
            scores['FORAGE'] += 0.32
            trace.append(RuleTrace('Peak frequency > 1200 Hz', 'FORAGE +0.32',
                'High-frequency range. Odontocete foraging and echolocation clicks.',
                f'{pf:.1f} Hz'))

        # ── Frequency Contour ─────────────────────────────────
        if fc == 'descending':
            scores['DIVE'] += 0.38
            trace.append(RuleTrace('Descending frequency contour', 'DIVE +0.38',
                'Descending sweeps reliably precede dive initiation in baleen whale records.',
                fc))
        elif fc == 'rising':
            scores['CONTACT'] += 0.38
            trace.append(RuleTrace('Rising frequency contour', 'CONTACT +0.38',
                'Rising sweeps (upcall pattern) are the canonical contact call shape.',
                fc))
        elif fc == 'complex':
            scores['BROADCAST'] += 0.32
            trace.append(RuleTrace('Complex multi-component contour', 'BROADCAST +0.32',
                'Hierarchically structured calls are characteristic of humpback song.',
                fc))
        elif fc == 'flat':
            scores['NAVIGATE'] += 0.18; scores['CONTACT'] += 0.10
            trace.append(RuleTrace('Flat (tonal) contour', 'NAVIGATE +0.18 · CONTACT +0.10',
                'Tonal flat calls are characteristic of regular navigation pulse trains.',
                fc))

        # ── Duration ──────────────────────────────────────────
        if dur > 5:
            scores['BROADCAST'] += 0.22; scores['NAVIGATE'] += 0.12
            trace.append(RuleTrace('Duration > 5 s', 'BROADCAST +0.22 · NAVIGATE +0.12',
                'Extended duration: sustained broadcast or long-period navigation signal.',
                f'{dur:.2f} s'))
        elif dur < 0.5:
            scores['DIVE'] += 0.16; scores['FORAGE'] += 0.12
            trace.append(RuleTrace('Duration < 0.5 s', 'DIVE +0.16 · FORAGE +0.12',
                'Brief impulsive signal. Dive initiation or foraging click burst.',
                f'{dur:.2f} s'))

        # ── Inter-Pulse Interval ──────────────────────────────
        if ipi is not None:
            if ipi < 50:
                scores['FORAGE'] += 0.28
                trace.append(RuleTrace('IPI < 50 ms', 'FORAGE +0.28',
                    'Very rapid IPI: odontocete foraging burst pulses.',
                    f'{ipi:.1f} ms'))
            elif ipi < 300:
                scores['FORAGE'] += 0.12; scores['CONTACT'] += 0.08
                trace.append(RuleTrace('IPI 50–300 ms', 'FORAGE +0.12 · CONTACT +0.08',
                    'Moderate IPI. Active social or foraging context.',
                    f'{ipi:.1f} ms'))
            elif ipi > 5000:
                scores['NAVIGATE'] += 0.22
                trace.append(RuleTrace('IPI > 5000 ms', 'NAVIGATE +0.22',
                    'Very slow pulse rate: long-period navigation signal.',
                    f'{ipi:.1f} ms'))

        # ── Urgency Index ─────────────────────────────────────
        if urg > 0.65:
            scores['FORAGE'] += 0.16
            trace.append(RuleTrace('Urgency index > 0.65', 'FORAGE +0.16',
                'High urgency composite: active prey pursuit or foraging coordination.',
                f'{urg:.3f}'))
        elif urg < 0.15:
            scores['NAVIGATE'] += 0.10; scores['BROADCAST'] += 0.10
            trace.append(RuleTrace('Urgency index < 0.15', 'NAVIGATE +0.10 · BROADCAST +0.10',
                'Low urgency: sustained low-energy navigation or broadcast signal.',
                f'{urg:.3f}'))

        # ── Strong-signal overrides ───────────────────────────
        final_class, confidence = None, None

        if fc == 'descending' and dur < 2.0:
            final_class, confidence = 'DIVE', 0.87
            trace.append(RuleTrace(
                'OVERRIDE: Descending contour + short duration',
                '→ DIVE (conf: 0.87)',
                'Near-diagnostic. Short descending sweeps precede dive events in all available baleen records.',
                f'{fc}, {dur:.2f}s'))

        elif fc == 'rising' and pf < 500:
            final_class, confidence = 'CONTACT', 0.82
            trace.append(RuleTrace(
                'OVERRIDE: Rising contour + low frequency',
                '→ CONTACT (conf: 0.82)',
                'Low-frequency rising sweep matches upcall pattern across NARW, humpback, bowhead.',
                f'{fc}, {pf:.1f}Hz'))

        elif pf < 30 and dur > 10:
            final_class, confidence = 'NAVIGATE', 0.79
            trace.append(RuleTrace(
                'OVERRIDE: Infrasonic + long duration',
                '→ NAVIGATE (conf: 0.79)',
                'Blue/fin whale SOFAR navigation signature.',
                f'{pf:.1f}Hz, {dur:.2f}s'))

        elif pf > 1500 and ipi is not None and ipi < 50:
            final_class, confidence = 'FORAGE', 0.83
            trace.append(RuleTrace(
                'OVERRIDE: High frequency + rapid IPI',
                '→ FORAGE (conf: 0.83)',
                'Odontocete foraging burst pulse signature.',
                f'{pf:.1f}Hz, {ipi:.1f}ms IPI'))

        elif fc == 'complex' and dur > 4:
            final_class, confidence = 'BROADCAST', 0.76
            trace.append(RuleTrace(
                'OVERRIDE: Complex contour + extended duration',
                '→ BROADCAST (conf: 0.76)',
                'Humpback song / broadcast behavior signature.',
                f'{fc}, {dur:.2f}s'))

        # Weighted score fallback
        if final_class is None:
            total = sum(scores.values()) + 1e-8
            probs = {k: v / total for k, v in scores.items()}
            final_class  = max(probs, key=probs.get)
            confidence   = round(probs[final_class], 4)

        # Always compute full probability distribution
        total = sum(scores.values()) + 1e-8
        probabilities = {k: round(v / total, 4) for k, v in scores.items()}

        return PredictionResult(
            predicted_class = final_class,
            confidence      = confidence,
            probabilities   = probabilities,
            rule_trace      = [asdict(t) for t in trace],
        )
