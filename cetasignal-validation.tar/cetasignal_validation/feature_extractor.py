"""
feature_extractor.py
────────────────────
Extracts acoustic features from raw WAV files for validation.

If you already have metadata (peakFrequency_hz, freqContour, etc.)
from NOAA/DCLDE annotation files, use dataset_loader.py directly.

This module is for when you have raw WAV files and need to derive features.
Wraps librosa for spectral analysis.

Usage:
  from feature_extractor import FeatureExtractor
  fe = FeatureExtractor()
  features = fe.extract('path/to/call.wav')
  # Returns dict compatible with CadenceEngine.predict()
"""

import os
import numpy as np
import pandas as pd

try:
    import librosa
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False
    print("[FeatureExtractor] librosa not installed. "
          "Install with: pip install librosa")
    print("[FeatureExtractor] Metadata-only mode active — "
          "pass pre-extracted features via dataset_loader.py")


class FeatureExtractor:
    """
    Extracts cadence-relevant acoustic features from WAV files.

    Features extracted:
      peakFrequency_hz      - dominant spectral frequency
      duration_s            - total call duration
      freqContour           - rising | descending | flat | complex
      interPulseInterval_ms - mean IPI from onset detection
      urgencyIndex          - composite urgency heuristic
      repetitionHz          - call repetition rate (if series)
      spectralCentroid_hz   - spectral center of mass
      bandwidth_hz          - -20dB spectral bandwidth
      zeroCrossingRate      - ZCR mean
      mfcc_1-13             - first 13 MFCC coefficients
    """

    def __init__(self, sr_target: int = 22050):
        """
        Args:
            sr_target : target sample rate for resampling (Hz).
                        Whale calls are typically <1kHz — 22050 is sufficient.
                        For high-frequency odontocete clicks, use sr_target=48000+
        """
        self.sr_target = sr_target

    def extract(self, wav_path: str) -> dict:
        """
        Extract features from a single WAV file.

        Args:
            wav_path : path to WAV file

        Returns:
            dict of features compatible with CadenceEngine
        """
        if not HAS_LIBROSA:
            raise RuntimeError("librosa required. Install: pip install librosa")

        y, sr = librosa.load(wav_path, sr=self.sr_target, mono=True)
        duration = librosa.get_duration(y=y, sr=sr)

        features = {}
        features['duration_s']        = round(duration, 4)
        features['peakFrequency_hz']   = self._peak_frequency(y, sr)
        features['freqContour']        = self._frequency_contour(y, sr)
        features['interPulseInterval_ms'] = self._inter_pulse_interval(y, sr)
        features['urgencyIndex']       = self._urgency_index(y, sr)
        features['repetitionHz']       = 0.0  # Requires series context — set externally
        features['spectralCentroid_hz'] = self._spectral_centroid(y, sr)
        features['bandwidth_hz']       = self._bandwidth(y, sr)
        features['zeroCrossingRate']   = float(np.mean(librosa.feature.zero_crossing_rate(y)))

        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        for i, coef in enumerate(np.mean(mfccs, axis=1), start=1):
            features[f'mfcc_{i}'] = round(float(coef), 4)

        return features

    def extract_batch(self, wav_dir: str, label_csv: str = None) -> pd.DataFrame:
        """
        Extract features from all WAV files in a directory.

        Args:
            wav_dir   : directory containing .wav files
            label_csv : optional CSV with filename → groundTruthBehavior mapping

        Returns:
            DataFrame with features (and labels if label_csv provided)
        """
        if not HAS_LIBROSA:
            raise RuntimeError("librosa required.")

        wav_files = [f for f in os.listdir(wav_dir) if f.endswith('.wav')]
        if not wav_files:
            raise FileNotFoundError(f"No WAV files found in {wav_dir}")

        labels = {}
        if label_csv:
            label_df = pd.read_csv(label_csv)
            if 'filename' in label_df.columns and 'groundTruthBehavior' in label_df.columns:
                labels = dict(zip(label_df['filename'], label_df['groundTruthBehavior']))

        records = []
        for wav_file in sorted(wav_files):
            path = os.path.join(wav_dir, wav_file)
            try:
                f = self.extract(path)
                f['filename'] = wav_file
                if wav_file in labels:
                    f['groundTruthBehavior'] = labels[wav_file]
                records.append(f)
                print(f"  ✓ {wav_file}  [{f['freqContour']}  {f['peakFrequency_hz']}Hz  {f['duration_s']}s]")
            except Exception as e:
                print(f"  ✗ {wav_file}: {e}")

        return pd.DataFrame(records)

    # ── Private feature methods ───────────────────────────────────

    def _peak_frequency(self, y: np.ndarray, sr: int) -> float:
        fft  = np.abs(np.fft.rfft(y))
        freqs = np.fft.rfftfreq(len(y), d=1.0/sr)
        idx  = np.argmax(fft)
        return round(float(freqs[idx]), 2)

    def _frequency_contour(self, y: np.ndarray, sr: int) -> str:
        """
        Estimate frequency modulation direction from spectrogram.
        Splits call into thirds and compares centroid evolution.
        """
        n     = len(y)
        third = n // 3
        if third < 512:
            return 'flat'

        def centroid(segment):
            fft   = np.abs(np.fft.rfft(segment))
            freqs = np.fft.rfftfreq(len(segment), d=1.0/sr)
            denom = np.sum(fft) + 1e-8
            return np.sum(freqs * fft) / denom

        c1 = centroid(y[:third])
        c2 = centroid(y[third:2*third])
        c3 = centroid(y[2*third:])

        delta_total  = c3 - c1
        delta_mid    = abs(c2 - (c1 + c3) / 2)
        range_hz     = max(c1, c2, c3) - min(c1, c2, c3)

        # Complex: significant non-monotonic movement
        if delta_mid > range_hz * 0.25 and range_hz > 30:
            return 'complex'
        if delta_total > 20:
            return 'rising'
        if delta_total < -20:
            return 'descending'
        return 'flat'

    def _inter_pulse_interval(self, y: np.ndarray, sr: int) -> float:
        """
        Estimate mean inter-pulse interval via onset detection.
        Returns None if fewer than 2 pulses detected.
        """
        try:
            onset_frames = librosa.onset.onset_detect(y=y, sr=sr, units='time')
            if len(onset_frames) < 2:
                return None
            intervals_s = np.diff(onset_frames)
            mean_ipi_ms = float(np.mean(intervals_s) * 1000)
            return round(mean_ipi_ms, 2)
        except Exception:
            return None

    def _urgency_index(self, y: np.ndarray, sr: int) -> float:
        """
        Composite urgency heuristic (0–1).
        High urgency = rapid onsets + high RMS amplitude.
        """
        rms = float(np.sqrt(np.mean(y**2)))
        rms_norm = min(rms * 10, 1.0)  # Rough normalization

        try:
            onsets = librosa.onset.onset_detect(y=y, sr=sr, units='time')
            duration = librosa.get_duration(y=y, sr=sr)
            onset_rate = len(onsets) / max(duration, 0.1)
            onset_norm = min(onset_rate / 20.0, 1.0)
        except Exception:
            onset_norm = 0.3

        urgency = 0.5 * rms_norm + 0.5 * onset_norm
        return round(float(urgency), 4)

    def _spectral_centroid(self, y: np.ndarray, sr: int) -> float:
        centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
        return round(float(np.mean(centroid)), 2)

    def _bandwidth(self, y: np.ndarray, sr: int) -> float:
        bw = librosa.feature.spectral_bandwidth(y=y, sr=sr)
        return round(float(np.mean(bw)), 2)
