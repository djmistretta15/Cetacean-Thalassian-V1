"""
evaluator.py
────────────
Runs full cross-validation comparison: CadenceEngine vs all baselines.

This is the scientific core of the validation pipeline.
It answers the question: does the cadence classifier perform
better than chance, and by how much?

Usage:
  from evaluator import Evaluator
  ev = Evaluator()
  results = ev.run_kfold(loader, n_splits=5)
  ev.print_comparison(results)
"""

import numpy as np
import pandas as pd
from collections import defaultdict

from cadence_engine import CadenceEngine
from baseline_models import RandomClassifier, MajorityClassifier, FrequencyPriorClassifier
from metrics import MetricsEngine

BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']
RANDOM_SEED = 42


class Evaluator:

    def __init__(self, classes=None):
        self.classes = classes or BEHAVIORAL_CLASSES
        self.metrics = MetricsEngine(classes=self.classes)
        self.cadence_engine = CadenceEngine()

    def run_kfold(self, loader, n_splits: int = 5) -> dict:
        """
        Run stratified k-fold cross-validation across all models.

        Args:
            loader   : CetaceanDatasetLoader instance
            n_splits : number of folds

        Returns:
            dict: aggregated results per model
        """
        print(f"\n[Evaluator] Running {n_splits}-fold cross-validation...\n")

        # Collect per-fold predictions
        fold_preds = {
            'CadenceEngine':      [],
            'RandomClassifier':   [],
            'MajorityClassifier': [],
            'FreqPriorClassifier': [],
        }
        fold_truths = []

        for fold, X_train, X_test, y_train, y_test in loader.kfold_splits(n_splits):
            print(f"  Fold {fold}/{n_splits}: {len(X_train)} train · {len(X_test)} test")

            # ── CadenceEngine (rule-based — no training needed) ──
            ce_result_df = self.cadence_engine.predict_batch(X_test)
            fold_preds['CadenceEngine'].extend(ce_result_df['predicted_class'].tolist())

            # ── Random baseline ───────────────────────────────────
            rand_clf = RandomClassifier(classes=self.classes)
            fold_preds['RandomClassifier'].extend(rand_clf.predict(X_test).tolist())

            # ── Majority baseline ─────────────────────────────────
            maj_clf = MajorityClassifier()
            maj_clf.fit(X_train, y_train)
            fold_preds['MajorityClassifier'].extend(maj_clf.predict(X_test).tolist())

            # ── Frequency prior baseline ──────────────────────────
            freq_clf = FrequencyPriorClassifier(seed=RANDOM_SEED + fold)
            freq_clf.fit(X_train, y_train)
            fold_preds['FreqPriorClassifier'].extend(freq_clf.predict(X_test).tolist())

            fold_truths.extend(y_test.tolist())

        # ── Compute metrics for each model ────────────────────────
        results = {}
        for model_name, preds in fold_preds.items():
            print(f"\n[Evaluator] Computing metrics: {model_name}...")
            report = self.metrics.compute(fold_truths, preds, label=model_name)
            results[model_name] = report

        return {
            'fold_results':   results,
            'ground_truth':   fold_truths,
            'predictions':    fold_preds,
            'n_folds':        n_splits,
            'n_samples':      len(fold_truths),
        }

    def run_holdout(self, loader, test_size: float = 0.2) -> dict:
        """
        Single train/test split evaluation.
        Faster than k-fold but less reliable for small datasets.
        """
        print(f"\n[Evaluator] Running holdout evaluation (test_size={test_size})...\n")

        X_train, X_test, y_train, y_test = loader.train_test_split(test_size)

        results = {}

        # CadenceEngine
        ce_df = self.cadence_engine.predict_batch(X_test)
        results['CadenceEngine'] = self.metrics.compute(
            y_test.tolist(), ce_df['predicted_class'].tolist(), 'CadenceEngine')

        # Random
        rand_clf = RandomClassifier(classes=self.classes)
        results['RandomClassifier'] = self.metrics.compute(
            y_test.tolist(), rand_clf.predict(X_test).tolist(), 'RandomClassifier')

        # Majority
        maj_clf = MajorityClassifier()
        maj_clf.fit(X_train, y_train)
        results['MajorityClassifier'] = self.metrics.compute(
            y_test.tolist(), maj_clf.predict(X_test).tolist(), 'MajorityClassifier')

        return {'fold_results': results, 'n_samples': len(X_test)}

    def print_comparison(self, eval_results: dict):
        """Print a clean comparison table to stdout."""
        results = eval_results['fold_results']
        print('\n' + '═' * 72)
        print('CETASIGNAL VALIDATION — MODEL COMPARISON')
        print(f"n_samples: {eval_results.get('n_samples', '?')}  "
              f"n_folds: {eval_results.get('n_folds', 'holdout')}")
        print('─' * 72)
        print(f"{'MODEL':<22} {'ACCURACY':>10} {'F1-MACRO':>10} {'KAPPA':>10} {'SIG?':>8}")
        print('─' * 72)

        random_acc = results.get('RandomClassifier', {}).get('overall', {}).get('accuracy', 0.2)

        for model, report in results.items():
            ov  = report['overall']
            sig = report['statistical_significance']['significant_alpha_0.05']
            acc = ov['accuracy']
            delta = acc - random_acc

            marker = '★' if (model == 'CadenceEngine' and sig) else (' ✓' if sig else '  ')
            print(f"  {model:<20} {acc:>9.1%} {ov['f1_macro']:>10.4f} "
                  f"{ov['cohens_kappa']:>10.4f} {'YES' if sig else 'no':>8}  "
                  f"{marker} (+{delta:+.1%} vs random)")

        print('═' * 72)

        ce = results.get('CadenceEngine', {})
        if ce:
            acc = ce['overall']['accuracy']
            sig = ce['statistical_significance']['significant_alpha_0.05']
            print(f"\n  INTERPRETATION:")
            if acc >= 0.75 and sig:
                print(f"  ✓ Strong result. {acc:.1%} accuracy, statistically significant.")
                print(f"    This is publishable-quality performance for a rule-based system.")
                print(f"    Next step: validate on real NOAA/DCLDE data (not synthetic).")
            elif acc >= 0.55 and sig:
                print(f"  ○ Moderate result. {acc:.1%} accuracy, significant vs random.")
                print(f"    Rules partially capture signal. Review confusion matrix for failure modes.")
                print(f"    Next step: expand rule system or add ML layer for low-confidence cases.")
            elif sig:
                print(f"  △ Weak but significant. {acc:.1%} > random baseline.")
                print(f"    Rules carry some information but need refinement.")
            else:
                print(f"  ✗ Not significant. Rules may be encoding the test set, not the domain.")
                print(f"    Increase dataset size or revise rule thresholds.")
        print()
