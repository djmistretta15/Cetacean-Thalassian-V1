"""
baseline_models.py
──────────────────
Baseline classifiers for comparison against the cadence engine.

Two baselines required by any credible evaluation:
  1. RandomClassifier    — predicts uniformly at random (expected ~20% for 5 classes)
  2. MajorityClassifier  — always predicts the most frequent class in training set

If the cadence engine does not significantly outperform both baselines,
the rule system provides no information beyond class distribution.

Usage:
  from baseline_models import RandomClassifier, MajorityClassifier
  random_clf = RandomClassifier(classes=['CONTACT','DIVE','FORAGE','NAVIGATE','BROADCAST'])
  majority_clf = MajorityClassifier()
  majority_clf.fit(y_train)
  preds = majority_clf.predict(X_test)
"""

import numpy as np
import pandas as pd
from collections import Counter

RANDOM_SEED = 42
BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']


class RandomClassifier:
    """
    Uniform random classifier.
    Expected accuracy = 1 / n_classes = 20% for 5 classes.
    This is the floor — any useful signal must exceed this.
    """

    def __init__(self, classes=None, seed=RANDOM_SEED):
        self.classes = classes or BEHAVIORAL_CLASSES
        self.rng = np.random.RandomState(seed)

    def fit(self, X, y=None):
        """No-op. Random classifier has no training phase."""
        return self

    def predict(self, X) -> np.ndarray:
        n = len(X) if hasattr(X, '__len__') else X
        return self.rng.choice(self.classes, size=n)

    def predict_proba(self, X) -> np.ndarray:
        n = len(X) if hasattr(X, '__len__') else X
        uniform = np.ones((n, len(self.classes))) / len(self.classes)
        return uniform

    @property
    def expected_accuracy(self) -> float:
        return 1.0 / len(self.classes)

    def __repr__(self):
        return f"RandomClassifier(classes={self.classes}, expected_acc={self.expected_accuracy:.2%})"


class MajorityClassifier:
    """
    Majority class classifier.
    Always predicts the most frequent class observed in training data.

    This baseline catches the case where class imbalance alone
    could explain high accuracy. A model must beat this to be informative.
    """

    def __init__(self):
        self.majority_class_ = None
        self.class_frequencies_ = None

    def fit(self, X, y):
        """
        Learn the majority class from training labels.
        X is ignored — only y matters.
        """
        counts = Counter(y)
        self.majority_class_ = max(counts, key=counts.get)
        total = sum(counts.values())
        self.class_frequencies_ = {k: v/total for k, v in counts.items()}
        print(f"[MajorityClassifier] Majority class: '{self.majority_class_}' "
              f"({self.class_frequencies_[self.majority_class_]:.1%} of training set)")
        return self

    def predict(self, X) -> np.ndarray:
        if self.majority_class_ is None:
            raise RuntimeError("Call fit() before predict()")
        n = len(X) if hasattr(X, '__len__') else X
        return np.array([self.majority_class_] * n)

    @property
    def majority_accuracy(self) -> float:
        """Expected accuracy on a dataset with same class distribution as training."""
        if self.class_frequencies_ is None:
            return None
        return self.class_frequencies_.get(self.majority_class_, 0.0)

    def __repr__(self):
        return (f"MajorityClassifier(majority='{self.majority_class_}', "
                f"freq={self.majority_accuracy:.2%})")


class FrequencyPriorClassifier:
    """
    Frequency-based prior: predicts the class proportional to training distribution.
    Stronger baseline than majority class — samples from distribution rather than
    always picking the mode. Represents a 'smart random' baseline.
    """

    def __init__(self, seed=RANDOM_SEED):
        self.class_probs_ = None
        self.classes_ = None
        self.rng = np.random.RandomState(seed)

    def fit(self, X, y):
        counts = Counter(y)
        total = sum(counts.values())
        self.classes_ = sorted(counts.keys())
        self.class_probs_ = np.array([counts.get(c, 0) / total for c in self.classes_])
        return self

    def predict(self, X) -> np.ndarray:
        if self.classes_ is None:
            raise RuntimeError("Call fit() before predict()")
        n = len(X) if hasattr(X, '__len__') else X
        return self.rng.choice(self.classes_, size=n, p=self.class_probs_)

    def __repr__(self):
        return f"FrequencyPriorClassifier(classes={self.classes_})"
