"""
metrics.py
──────────
Evaluation metrics for the CetaSignal validation pipeline.

Computes:
  - Accuracy
  - Precision (macro + per-class)
  - Recall    (macro + per-class)
  - F1        (macro + per-class)
  - Confusion matrix
  - Cohen's Kappa (inter-rater agreement vs chance)
  - Statistical significance vs baseline (binomial test)

Outputs:
  - JSON report (metrics_report.json)
  - Confusion matrix PNG (confusion_matrix.png)
  - Human-readable summary (summary.txt)

Usage:
  from metrics import MetricsEngine
  me = MetricsEngine(classes=['CONTACT','DIVE','FORAGE','NAVIGATE','BROADCAST'])
  report = me.compute(y_true, y_pred, label='CadenceEngine')
  me.save_report(report, out_dir='./results')
"""

import json
import os
import numpy as np
import pandas as pd
from datetime import datetime
from collections import Counter
from scipy import stats

from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
    cohen_kappa_score,
    classification_report,
)

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mticker
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("[metrics] matplotlib not installed — confusion matrix PNG will be skipped.")

BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']


class MetricsEngine:

    def __init__(self, classes=None):
        self.classes = classes or BEHAVIORAL_CLASSES

    def compute(self, y_true, y_pred, label: str = 'Model') -> dict:
        """
        Compute full evaluation metrics for a set of predictions.

        Args:
            y_true  : ground truth labels (list or array)
            y_pred  : predicted labels (list or array)
            label   : model identifier for the report

        Returns:
            dict: complete metrics report
        """
        y_true = np.array(y_true)
        y_pred = np.array(y_pred)
        n = len(y_true)

        accuracy = accuracy_score(y_true, y_pred)

        prec, rec, f1, support = precision_recall_fscore_support(
            y_true, y_pred,
            labels=self.classes,
            average=None,
            zero_division=0
        )

        prec_macro = float(np.mean(prec))
        rec_macro  = float(np.mean(rec))
        f1_macro   = float(np.mean(f1))

        kappa = cohen_kappa_score(y_true, y_pred)

        cm = confusion_matrix(y_true, y_pred, labels=self.classes)

        # Binomial test vs random baseline (expected p = 1/n_classes)
        n_correct = int(np.sum(y_true == y_pred))
        random_p  = 1.0 / len(self.classes)
        binom     = stats.binomtest(n_correct, n, random_p, alternative='greater')
        p_value   = binom.pvalue
        significant_vs_random = p_value < 0.05

        # Per-class metrics
        per_class = {}
        for i, cls in enumerate(self.classes):
            per_class[cls] = {
                'precision':   round(float(prec[i]), 4),
                'recall':      round(float(rec[i]),  4),
                'f1_score':    round(float(f1[i]),   4),
                'support':     int(support[i]),
                'correct':     int(cm[i, i]),
            }

        report = {
            'metadata': {
                'model_label':       label,
                'timestamp':         datetime.utcnow().isoformat() + 'Z',
                'n_samples':         n,
                'n_classes':         len(self.classes),
                'classes':           self.classes,
                'random_baseline':   round(random_p, 4),
            },
            'overall': {
                'accuracy':          round(float(accuracy), 4),
                'precision_macro':   round(prec_macro, 4),
                'recall_macro':      round(rec_macro,  4),
                'f1_macro':          round(f1_macro,   4),
                'cohens_kappa':      round(float(kappa), 4),
                'n_correct':         n_correct,
                'n_incorrect':       n - n_correct,
            },
            'statistical_significance': {
                'test':                    'one-tailed binomial test vs random baseline',
                'null_hypothesis':         f'accuracy <= random ({random_p:.2%})',
                'p_value':                 round(p_value, 6),
                'significant_alpha_0.05':  significant_vs_random,
                'interpretation': (
                    f"Model accuracy ({accuracy:.2%}) is "
                    + ("significantly" if significant_vs_random else "NOT significantly")
                    + f" better than random chance ({random_p:.2%}), p={p_value:.4f}"
                )
            },
            'per_class': per_class,
            'confusion_matrix': {
                'labels': self.classes,
                'matrix': cm.tolist(),
            },
        }

        return report

    def compare(self, results: list) -> dict:
        """
        Compare multiple model results side by side.

        Args:
            results : list of dicts from compute()

        Returns:
            dict: comparison table
        """
        comparison = {
            'models': [],
            'winner': None,
        }
        best_f1 = -1
        for r in results:
            entry = {
                'label':          r['metadata']['model_label'],
                'accuracy':       r['overall']['accuracy'],
                'f1_macro':       r['overall']['f1_macro'],
                'cohens_kappa':   r['overall']['cohens_kappa'],
                'significant':    r['statistical_significance']['significant_alpha_0.05'],
            }
            comparison['models'].append(entry)
            if entry['f1_macro'] > best_f1:
                best_f1 = entry['f1_macro']
                comparison['winner'] = entry['label']

        return comparison

    def save_report(self, report: dict, out_dir: str = './results', label: str = None):
        """Save JSON report, confusion matrix PNG, and summary TXT."""
        os.makedirs(out_dir, exist_ok=True)
        tag = label or report['metadata']['model_label'].replace(' ', '_').lower()

        # JSON
        json_path = os.path.join(out_dir, f'metrics_{tag}.json')
        class _NumpyEncoder(json.JSONEncoder):
            def default(self, obj):
                if isinstance(obj, (np.bool_, np.integer)): return int(obj)
                if isinstance(obj, np.floating): return float(obj)
                if isinstance(obj, np.ndarray): return obj.tolist()
                return super().default(obj)
        with open(json_path, 'w') as f:
            json.dump(report, f, indent=2, cls=_NumpyEncoder)
        print(f"[metrics] Report saved → {json_path}")

        # Confusion matrix PNG
        if HAS_MATPLOTLIB:
            png_path = os.path.join(out_dir, f'confusion_matrix_{tag}.png')
            self._plot_confusion_matrix(report, png_path)
            print(f"[metrics] Confusion matrix → {png_path}")

        # Summary TXT
        txt_path = os.path.join(out_dir, f'summary_{tag}.txt')
        self._write_summary(report, txt_path)
        print(f"[metrics] Summary → {txt_path}")

        return json_path

    def _plot_confusion_matrix(self, report: dict, path: str):
        labels = report['confusion_matrix']['labels']
        cm     = np.array(report['confusion_matrix']['matrix'])
        n      = cm.sum()

        # Normalize for display
        cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-8)

        fig, ax = plt.subplots(figsize=(8, 7))
        fig.patch.set_facecolor('#07090F')
        ax.set_facecolor('#07090F')

        im = ax.imshow(cm_norm, cmap='Blues', vmin=0, vmax=1)

        for i in range(len(labels)):
            for j in range(len(labels)):
                count = cm[i, j]
                pct   = cm_norm[i, j]
                color = 'white' if pct > 0.5 else '#C8D8E8'
                ax.text(j, i, f'{count}\n({pct:.0%})',
                        ha='center', va='center', fontsize=9,
                        color=color, fontfamily='monospace')

        ax.set_xticks(range(len(labels)))
        ax.set_yticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=30, ha='right', color='#8AAABB', fontsize=9)
        ax.set_yticklabels(labels, color='#8AAABB', fontsize=9)
        ax.tick_params(colors='#3A5A6A')
        for spine in ax.spines.values():
            spine.set_edgecolor('#132030')

        ax.set_xlabel('PREDICTED', color='#5A7A8A', fontsize=10, labelpad=12)
        ax.set_ylabel('OBSERVED (GROUND TRUTH)', color='#5A7A8A', fontsize=10, labelpad=12)

        model_label = report['metadata']['model_label']
        acc         = report['overall']['accuracy']
        f1          = report['overall']['f1_macro']
        kappa       = report['overall']['cohens_kappa']
        n_samples   = report['metadata']['n_samples']

        ax.set_title(
            f'{model_label}\n'
            f'Accuracy: {acc:.1%}  ·  F1 (macro): {f1:.3f}  ·  κ: {kappa:.3f}  ·  n={n_samples}',
            color='#8AAABB', fontsize=10, pad=16, fontfamily='monospace'
        )

        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(colors='#5A7A8A', labelsize=8)
        cbar.ax.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1))

        plt.tight_layout()
        plt.savefig(path, dpi=150, facecolor='#07090F', bbox_inches='tight')
        plt.close()

    def _write_summary(self, report: dict, path: str):
        lines = [
            '═' * 60,
            f"CETASIGNAL VALIDATION REPORT",
            f"Model:     {report['metadata']['model_label']}",
            f"Timestamp: {report['metadata']['timestamp']}",
            f"Samples:   {report['metadata']['n_samples']}",
            '═' * 60,
            '',
            'OVERALL METRICS',
            '─' * 40,
            f"  Accuracy:          {report['overall']['accuracy']:.4f}  ({report['overall']['accuracy']:.1%})",
            f"  Precision (macro): {report['overall']['precision_macro']:.4f}",
            f"  Recall (macro):    {report['overall']['recall_macro']:.4f}",
            f"  F1 (macro):        {report['overall']['f1_macro']:.4f}",
            f"  Cohen's Kappa:     {report['overall']['cohens_kappa']:.4f}",
            f"  Correct:           {report['overall']['n_correct']} / {report['metadata']['n_samples']}",
            '',
            'STATISTICAL SIGNIFICANCE',
            '─' * 40,
            f"  {report['statistical_significance']['interpretation']}",
            f"  p-value: {report['statistical_significance']['p_value']:.6f}",
            '',
            'PER-CLASS METRICS',
            '─' * 40,
        ]
        for cls, m in report['per_class'].items():
            lines.append(
                f"  {cls:<12}  P: {m['precision']:.3f}  R: {m['recall']:.3f}  "
                f"F1: {m['f1_score']:.3f}  n={m['support']}"
            )

        lines += [
            '',
            'CONFUSION MATRIX (rows=truth, cols=predicted)',
            '─' * 40,
        ]
        classes = report['confusion_matrix']['labels']
        cm      = report['confusion_matrix']['matrix']
        header  = '  ' + '  '.join(f'{c[:8]:>8}' for c in classes)
        lines.append(header)
        for i, cls in enumerate(classes):
            row = '  '.join(f'{cm[i][j]:>8}' for j in range(len(classes)))
            lines.append(f"  {cls[:8]:<8}  {row}")

        lines += ['', '═' * 60]

        with open(path, 'w') as f:
            f.write('\n'.join(lines))
