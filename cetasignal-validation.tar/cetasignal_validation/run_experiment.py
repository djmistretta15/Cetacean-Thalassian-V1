"""
run_experiment.py
─────────────────
CetaSignal Validation Pipeline — CLI entry point.

This is the single command that runs the complete experiment:
  1. Load dataset (real CSV/JSON or synthetic)
  2. Run stratified k-fold cross-validation
  3. Evaluate CadenceEngine vs all baselines
  4. Compute metrics: accuracy, precision, recall, F1, confusion matrix, kappa
  5. Statistical significance test vs random baseline
  6. Save all outputs to results/

Usage:
  # With real data:
  python run_experiment.py --data dataset.csv --kfold 5 --out results/

  # With synthetic data (pipeline test only):
  python run_experiment.py --synthetic --n 500 --kfold 5

  # Holdout split instead of k-fold:
  python run_experiment.py --data dataset.csv --mode holdout --test_size 0.2

Output files:
  results/metrics_cadenceengine.json
  results/metrics_randomclassifier.json
  results/metrics_majorityclassifier.json
  results/confusion_matrix_cadenceengine.png
  results/summary_cadenceengine.txt
  results/comparison.json
  results/comparison_summary.txt
"""

import argparse
import json
import os
import sys
from datetime import datetime

from dataset_loader   import CetaceanDatasetLoader, generate_synthetic_dataset
from evaluator        import Evaluator
from metrics          import MetricsEngine

BEHAVIORAL_CLASSES = ['CONTACT', 'DIVE', 'FORAGE', 'NAVIGATE', 'BROADCAST']
RANDOM_SEED = 42


def run(args):
    print('\n' + '═' * 60)
    print('  CETASIGNAL VALIDATION PIPELINE')
    print(f'  {datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")} UTC')
    print('═' * 60 + '\n')

    os.makedirs(args.out, exist_ok=True)

    # ── Load dataset ──────────────────────────────────────────────
    if args.synthetic:
        print(f"[Pipeline] Generating synthetic dataset (n={args.n})...")
        print("  ⚠  WARNING: Synthetic data is generated from the same rules as the")
        print("     classifier. Results on synthetic data DO NOT constitute real validation.")
        print("     Use real NOAA/DCLDE data for scientific claims.\n")
        df = generate_synthetic_dataset(n=args.n)
        loader = CetaceanDatasetLoader(df=df)

    elif args.data:
        print(f"[Pipeline] Loading dataset: {args.data}")
        loader = CetaceanDatasetLoader(filepath=args.data)

    else:
        print("[Pipeline] ERROR: Provide --data <file> or --synthetic")
        sys.exit(1)

    # Save dataset summary
    summary = loader.summary()
    summary_path = os.path.join(args.out, 'dataset_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"[Pipeline] Dataset summary → {summary_path}")

    # ── Run evaluation ────────────────────────────────────────────
    evaluator = Evaluator(classes=BEHAVIORAL_CLASSES)
    metrics   = MetricsEngine(classes=BEHAVIORAL_CLASSES)

    if args.mode == 'kfold':
        print(f"\n[Pipeline] Running {args.kfold}-fold cross-validation...\n")
        eval_results = evaluator.run_kfold(loader, n_splits=args.kfold)
    else:
        print(f"\n[Pipeline] Running holdout evaluation (test_size={args.test_size})...\n")
        eval_results = evaluator.run_holdout(loader, test_size=args.test_size)

    # ── Save individual model reports ─────────────────────────────
    for model_name, report in eval_results['fold_results'].items():
        metrics.save_report(report, out_dir=args.out, label=model_name.lower())

    # ── Comparison summary ────────────────────────────────────────
    comparison = metrics.compare(list(eval_results['fold_results'].values()))
    class _NE(json.JSONEncoder):
        def default(self, obj):
            import numpy as np
            if isinstance(obj, (np.bool_, np.integer)): return int(obj)
            if isinstance(obj, np.floating): return float(obj)
            return super().default(obj)
    comp_path = os.path.join(args.out, 'comparison.json')
    with open(comp_path, 'w') as f:
        json.dump(comparison, f, indent=2, cls=_NE)
    print(f"\n[Pipeline] Comparison → {comp_path}")

    # ── Print comparison table ────────────────────────────────────
    evaluator.print_comparison(eval_results)

    # ── Write comparison summary text ────────────────────────────
    _write_comparison_summary(eval_results, comparison, args, summary)

    print(f"\n[Pipeline] All outputs saved → {os.path.abspath(args.out)}/\n")
    print("  Next steps:")
    print("  1. Review confusion_matrix_cadenceengine.png for failure modes")
    print("  2. Check per-class F1 — which behavioral classes are hardest to predict?")
    print("  3. If using synthetic data, repeat with real NOAA/DCLDE CSV")
    print("  4. If accuracy is significant: document in research note")
    print("  5. If accuracy is weak: review rule thresholds in cadence_engine.py\n")


def _write_comparison_summary(eval_results, comparison, args, dataset_summary):
    results = eval_results['fold_results']
    out_dir = args.out

    lines = [
        '═' * 70,
        'CETASIGNAL VALIDATION — COMPARISON SUMMARY',
        f"Timestamp: {datetime.utcnow().isoformat()}Z",
        f"Dataset:   {'synthetic (pipeline test only)' if args.synthetic else args.data}",
        f"Samples:   {eval_results.get('n_samples', '?')}",
        f"Method:    {args.kfold}-fold cross-validation" if args.mode == 'kfold'
                    else f"Holdout (test_size={args.test_size})",
        '═' * 70,
        '',
        'CLASS DISTRIBUTION IN DATASET:',
    ]

    dist = dataset_summary.get('class_distribution', {})
    for cls, count in dist.items():
        pct = dataset_summary.get('class_balance', {}).get(cls, 0)
        lines.append(f"  {cls:<12}  {count:>5} samples  ({pct:.1%})")

    lines += ['', 'MODEL COMPARISON:', '─' * 70,
              f"  {'MODEL':<22} {'ACCURACY':>10} {'F1-MACRO':>10} {'KAPPA':>10} {'SIGNIFICANT':>12}"]
    lines.append('─' * 70)

    for m in comparison['models']:
        lines.append(
            f"  {m['label']:<22} {m['accuracy']:>10.1%} {m['f1_macro']:>10.4f} "
            f"{m['cohens_kappa']:>10.4f} {'YES' if m['significant'] else 'no':>12}"
        )

    lines += ['', f"  WINNER: {comparison['winner']}", '', 'INTERPRETATION:']

    ce = results.get('CadenceEngine', {})
    rand = results.get('RandomClassifier', {})
    if ce and rand:
        ce_acc    = ce['overall']['accuracy']
        rand_acc  = rand['overall']['accuracy']
        ce_f1     = ce['overall']['f1_macro']
        ce_kappa  = ce['overall']['cohens_kappa']
        ce_sig    = ce['statistical_significance']['significant_alpha_0.05']
        delta     = ce_acc - rand_acc

        if ce_acc >= 0.75 and ce_sig:
            lines.append(f"  STRONG: {ce_acc:.1%} accuracy (+{delta:.1%} vs random), F1={ce_f1:.3f}, κ={ce_kappa:.3f}")
            lines.append(f"  This constitutes a publishable result for a rule-based system.")
            lines.append(f"  Proceed with real NOAA/DCLDE data validation.")
        elif ce_acc >= 0.55 and ce_sig:
            lines.append(f"  MODERATE: {ce_acc:.1%} accuracy (+{delta:.1%} vs random)")
            lines.append(f"  Rules carry information. Review confusion matrix for failure modes.")
            lines.append(f"  Consider ML ensemble layer for ambiguous cases.")
        elif ce_sig:
            lines.append(f"  WEAK BUT SIGNIFICANT: {ce_acc:.1%} accuracy")
            lines.append(f"  Rules are informative but need refinement.")
        else:
            lines.append(f"  NOT SIGNIFICANT: Results may reflect rule-data alignment, not generalization.")
            lines.append(f"  Increase sample size or revise rule thresholds.")

        if args.synthetic:
            lines += ['',
                '  ⚠  SYNTHETIC DATA WARNING:',
                '     These results are from synthetic data generated by the same',
                '     rule templates that parameterize the classifier.',
                '     They demonstrate pipeline correctness, NOT scientific validity.',
                '     Repeat this experiment with real NOAA/DCLDE labeled data.']

    lines += ['', '═' * 70]

    txt_path = os.path.join(out_dir, 'comparison_summary.txt')
    with open(txt_path, 'w') as f:
        f.write('\n'.join(lines))
    print(f"[Pipeline] Comparison summary → {txt_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='CetaSignal Validation Pipeline',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_experiment.py --synthetic --n 500 --kfold 5
  python run_experiment.py --data dclde_annotated.csv --kfold 5
  python run_experiment.py --data noaa_nefsc.csv --mode holdout --test_size 0.2
        """
    )

    # Input
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('--data',      type=str, help='Path to CSV or JSON dataset')
    input_group.add_argument('--synthetic', action='store_true', help='Generate synthetic test dataset (pipeline test only)')

    # Dataset options
    parser.add_argument('--n', type=int, default=500,
                        help='Number of synthetic specimens (default: 500)')
    parser.add_argument('--noise', type=float, default=0.15,
                        help='Noise level for synthetic data (default: 0.15)')

    # Evaluation mode
    parser.add_argument('--mode', type=str, default='kfold',
                        choices=['kfold', 'holdout'], help='Evaluation mode (default: kfold)')
    parser.add_argument('--kfold', type=int, default=5,
                        help='Number of folds for k-fold CV (default: 5)')
    parser.add_argument('--test_size', type=float, default=0.2,
                        help='Test fraction for holdout mode (default: 0.2)')

    # Output
    parser.add_argument('--out', type=str, default='./results',
                        help='Output directory (default: ./results)')

    args = parser.parse_args()
    run(args)
